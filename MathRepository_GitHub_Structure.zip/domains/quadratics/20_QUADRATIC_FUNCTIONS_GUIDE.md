# Quadratic Functions Guide
